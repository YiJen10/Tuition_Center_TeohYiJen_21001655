public class Student {
    // data/attributes
    public Name name;
    protected String ic;
    protected String address;
    protected String school_name;
    protected String tutor_name;
    private final float[] marks = new float[5];

    public Student(){ //constructor
        name = new Name();
    }

    public Student(String fname, String mname, String lname){ //constructor
        name = new Name(fname,mname,lname);
    }

    //methods or operations
    public void setName(Name input){
        name = input;
    }

    public void setIC(String ic){
        this.ic = ic;
    }
    public void setAddress(String address){
        this.address = address;
    }

    public void setSchool_name(String school_name){
        this.school_name = school_name;
    }
    public void setTutor_name(String tutor_name){
        this.tutor_name = tutor_name;
    }

    public void setMarks(float m,int i){
        marks[i] = m;
    }
    public float calcAvg(){
        float total=0;
        for(int i=0;i<5;i++){
            total += marks[i];
        }
        return total/5;
    }

    public float findMin(){
        float min = 9999999;
        for(int i=0;i<5;i++){
            if(marks[i]<min){
                min = marks[i];
            }
        }
        return min;
    }
    public float findMax(){
        float max = -9999999;
        for(int i=0;i<5;i++){
            if(marks[i]>max){
                max = marks[i];
            }
        }
        return max;
    }
}
